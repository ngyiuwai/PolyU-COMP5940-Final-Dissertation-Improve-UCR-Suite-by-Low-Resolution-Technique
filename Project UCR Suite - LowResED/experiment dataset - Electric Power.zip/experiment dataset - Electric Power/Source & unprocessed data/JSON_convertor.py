import os
import json

script_dir = os.path.dirname(__file__)
read_path = os.path.join(script_dir, 'household_power_consumption.txt')

output = []

with open(read_path, "r") as textfile:
	textfile.readline()
	while True :
		row = textfile.readline()
		if (row == ""):
			break
		terms = row.split(";")
		if (len(terms)>2) and (terms[2] != '?'):
			pwr_consumption = float(terms[2])
			pwr_consumption2 = float(terms[2])
			output.append(pwr_consumption)

textfile.close()

print(len(output))

save_path = os.path.join(script_dir, 'data.json')
textfile = open(save_path, "w")
textfile.write(json.dumps(output))
textfile.close()
