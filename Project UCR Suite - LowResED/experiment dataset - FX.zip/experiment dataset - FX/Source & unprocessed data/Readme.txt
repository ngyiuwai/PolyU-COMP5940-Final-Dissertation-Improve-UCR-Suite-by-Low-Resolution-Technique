Data are downloaded here.

https://www.histdata.com/

It is per minute AUD/USD, EUR/USD, USD/JPY price data for 3 year.
I forgot which 3 years are choosen... It should be within 2015 - 2019.